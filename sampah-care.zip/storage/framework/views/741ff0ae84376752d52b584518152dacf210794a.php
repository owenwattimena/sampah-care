<div class="sidebar-wrapper" data-simplebar="true">
    <div class="sidebar-header">
        
        <div>
            <h4 class="logo-text">Sampah Care</h4>
        </div>
        <div class="toggle-icon ms-auto"><i class='bx bx-arrow-to-left'></i>
        </div>
    </div>
    <!--navigation-->
    <ul class="metismenu" id="menu">
        <li>
            <a href="<?php echo e(url('/')); ?>">
                <div class="parent-icon"><i class="bx bx-home"></i>
                </div>
                <div class="menu-title">Dashboard</div>
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('pengaduan')); ?>">
                <div class="parent-icon"><i class="bx bx-message-rounded"></i>
                </div>
                <div class="menu-title">Pengaduan</div>
            </a>
        </li>
        <?php if(auth()->guard('admin')->user()->level == 'admin'): ?>

        <li>
            <a href="<?php echo e(route('pengguna')); ?>">
                <div class="parent-icon"><i class="bx bx-user"></i>
                </div>
                <div class="menu-title">Pengguna</div>
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('admin')); ?>">
                <div class="parent-icon"><i class="bx bx-user"></i>
                </div>
                <div class="menu-title">Admin</div>
            </a>
        </li>
        <?php endif; ?>

    </ul>
    <!--end navigation-->
</div>
<!--end sidebar wrapper -->
<?php /**PATH E:\laragon-php8\www\sampah-care\resources\views/templates/sidebar.blade.php ENDPATH**/ ?>