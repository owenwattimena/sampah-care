<?php $__env->startSection('style'); ?>
<link href="assets/plugins/datatable/css/dataTables.bootstrap5.min.css" rel="stylesheet" />
<!-- Leaflet -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="" />
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Pengaduan'); ?>
<?php $__env->startSection('subtitle', 'Detail Pengaduan'); ?>


<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <div class="card border-start border-info">
            <div class="card-body">
                <h5>Pengaduan</h5>
            </div>
        </div>
        <div class="mb-3 row">
            <label for="staticNIK" class="col-sm-2 col-form-label">Status</label>
            <div class="col-sm-10">
                <span class="badge bg-<?php echo e($pengaduan->status == 'pending' ? 'danger' : ($pengaduan->status == 'proses' ? 'primary' : 'success')); ?>"><?php echo e($pengaduan->status); ?></span>
            </div>
        </div>
        <div class="mb-3 row">
            <label for="staticNIK" class="col-sm-2 col-form-label">NIK</label>
            <div class="col-sm-10">
                <input type="text" readonly class="form-control-plaintext" id="staticNIK" value="<?php echo e($pengaduan->user->nik); ?>">
            </div>
        </div>
        <div class="mb-3 row">
            <label for="staticNama" class="col-sm-2 col-form-label">Nama</label>
            <div class="col-sm-10">
                <input type="text" readonly class="form-control-plaintext" id="staticNama" value="<?php echo e($pengaduan->user->nama); ?>">
            </div>
        </div>
        <div class="mb-3 row">
            <label for="staticFoto" class="col-sm-2 col-form-label">Foto</label>
            <div class="col-sm-10">
                <img src="<?php echo e(asset($pengaduan->foto)); ?>" alt="" width="50%">
            </div>
        </div>
        <div class="mb-3 row">
            <label for="staticIsi" class="col-sm-2 col-form-label">Isi</label>
            <div class="col-sm-10">
                <textarea type="text" readonly class="form-control-plaintext" id="staticIsi"><?php echo e($pengaduan->isi); ?></textarea>
            </div>
        </div>
        <div class="mb-3 row">
            <label for="staticIsi" class="col-sm-2 col-form-label">Lokasi</label>
            <div class="col-sm-10">
                <div id="map" class="map map-home" style="height: 500px; margin-top: 50px"></div>
            </div>
        </div>
        <div class="card border-start border-info">
            <div class="card-body">
                <h5>Tanggapan</h5>
            </div>
        </div>
        <form action="<?php echo e(route('pengaduan.tanggapi', $pengaduan->id)); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="mb-3 row">
                <label for="selectStatus" class="col-sm-2 col-form-label">Status</label>
                <div class="col-sm-10">
                    <select type="text" class="form-control" id="selectStatus" name="status" required <?php echo e($editTanggapan ? '' : 'readonly disabled'); ?>>
                        <?php $__currentLoopData = ['pending', 'proses', 'selesai']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item); ?>" <?php echo e($pengaduan->status == $item ? 'selected' : ''); ?>><?php echo e($item); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="mb-3 row">
                <label for="inputTanggapan" class="col-sm-2 col-form-label">Isi</label>
                <div class="col-sm-10">
                    <textarea class="form-control" id="inputTanggapan" name="isi" placeholder="Masukan Tanggapan" <?php echo e($editTanggapan ? '' : 'readonly disabled'); ?>><?php echo e($pengaduan->tanggapan->isi ?? ''); ?></textarea>
                </div>
            </div>
            <div class="mb-3 row">
                <label for="inputFoto" class="col-sm-2 col-form-label">Foto</label>
                <div class="col-sm-10">
                    <?php if($pengaduan->tanggapan != null ): ?>
                    <?php if($pengaduan->tanggapan->foto != null ): ?>
                    <img src="<?php echo e(asset($pengaduan->tanggapan->foto)); ?>" alt="" width="50%" class="mb-3">
                    <?php endif; ?>
                    <?php endif; ?>
                    <?php if($editTanggapan): ?>
                    <input type="file" class="form-control" id="inputFoto" name="foto">
                    <?php endif; ?>
                </div>
            </div>
            <?php if($editTanggapan): ?>

            <div class="mb-3 row">
                <div class="col-sm-12">
                    <button type="submit" class="form-control btn btn-success">SIMPAN</button>
                </div>
            </div>
            <?php endif; ?>

        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
<script src="assets/plugins/datatable/js/dataTables.bootstrap5.min.js"></script>
<script>
    var osmUrl = 'https://tile.openstreetmap.org/{z}/{x}/{y}.png'
        , osmAttrib = '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        , osm = L.tileLayer(osmUrl, {
            maxZoom: 18
            , attribution: osmAttrib
        });

    var map = L.map('map').setView([`<?php echo e($pengaduan->latitude); ?>`, `<?php echo e($pengaduan->longitude); ?>`], 15).addLayer(osm);

    L.marker([`<?php echo e($pengaduan->latitude); ?>`, `<?php echo e($pengaduan->longitude); ?>`])
        .addTo(map);
    // .bindPopup('A pretty CSS popup.<br />Easily customizable.')
    // .openPopup();

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon-php8\www\sampah-care\resources\views/admin/pengaduan/show.blade.php ENDPATH**/ ?>