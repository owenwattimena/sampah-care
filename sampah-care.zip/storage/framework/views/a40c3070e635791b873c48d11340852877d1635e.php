<?php $__env->startSection('style'); ?>
<link href="assets/plugins/datatable/css/dataTables.bootstrap5.min.css" rel="stylesheet" />
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Pengaduan'); ?>
<?php $__env->startSection('subtitle', 'Daftar Pengaduan'); ?>


<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <div>
            <form action="">
                <div class="row">
                    <div class="col-md-2 mb-3">
                        <label for="inputTglMulai" class="form-label">Awal</label>
                        <input type="date" class="form-control" id="inputTglMulai" name="awal" value="<?php echo e($awal); ?>">
                    </div>
                    <div class="col-md-2 mb-3">
                        <label for="inputTglAkhir" class="form-label">Akhir</label>
                        <input type="date" class="form-control" id="inputTglAkhir" name="akhir" value="<?php echo e($akhir); ?>">
                    </div>
                    <div class="col-md-1 mb-3">
                        <label for="inputStatus" class="form-label">Status</label>
                        <select class="form-control" id="inputStatus" name="status">
                            <option value="pending" <?php echo e($status == 'pending' ? 'selected' : ''); ?>>Pending</option>
                            <option value="proses" <?php echo e($status == 'proses' ? 'selected' : ''); ?>>Proses</option>
                            <option value="selesai" <?php echo e($status == 'selesai' ? 'selected' : ''); ?>>Selesai</option>
                        </select>
                    </div>
                    <div class="col-md-1 mb-3">
                        <label for="inputStatus" class="form-label">_</label>
                        <button class="form-control" id="inputTglAkhir" name="akhir">Filter</button>
                    </div>
                </div>
            </form>
        </div>
        <div class="table-responsive">
            <table id="example" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th>NIK</th>
                        <th>Nama</th>
                        <th>Hari/Tanggal</th>
                        <th>Isi Pengaduan</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pengaduan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->user->nik); ?></td>
                        <td><?php echo e($item->user->nama); ?></td>
                        <td><?php echo e($item->created_at); ?></td>
                        <td><?php echo e($item->isi); ?></td>
                        <td><span class="badge bg-<?php echo e($item->status == 'pending' ? 'danger' : ($item->status == 'proses' ? 'primary' : 'success')); ?>"><?php echo e($item->status); ?></span></td>
                        <td>
                            <a class="btn btn-sm btn-success" href="<?php echo e(route('pengaduan.show', $item->id)); ?>">Lihat</a>
                            <?php if(auth()->guard('admin')->user()->level == 'admin'): ?>
                            <form action="<?php echo e(route('pengaduan.delete', $item->id)); ?>" method="post" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus data?')">Hapus</button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
<script src="assets/plugins/datatable/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>
<script>
    $(document).ready(function() {
        $('#example').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'print'
        ]
        });
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon-php8\www\sampah-care\resources\views/admin/pengaduan/index.blade.php ENDPATH**/ ?>