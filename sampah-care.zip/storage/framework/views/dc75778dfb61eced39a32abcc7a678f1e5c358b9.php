<?php $__env->startSection('title', 'Dashboard'); ?>



<?php $__env->startSection('content'); ?>
<div class="card radius-10">
    <div class="card-content">
        <div class="row row-group row-cols-1 row-cols-xl-3">
            <div class="col">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div>
                            <p class="mb-0">Pending</p>
                            <h4 class="mb-0 text-danger"><?php echo e($statistik['pending']); ?></h4>
                        </div>
                        <div class="ms-auto"><i class="bx bx-plus font-35 text-danger"></i>
                        </div>
                    </div>
                    <div class="progress radius-10 my-2" style="height:4px;">
                        <div class="progress-bar bg-danger" role="progressbar" style="width: 100%"></div>
                    </div>
                    <p class="mb-0 font-13">Data pengaduan status pending</p>
                </div>
            </div>
            <div class="col">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div>
                            <p class="mb-0">Proses</p>
                            <h4 class="mb-0 text-primary"><?php echo e($statistik['proses']); ?></h4>
                        </div>
                        <div class="ms-auto"><i class="bx bx-bus font-35 text-primary"></i>
                        </div>
                    </div>
                    <div class="progress radius-10 my-2" style="height:4px;">
                        <div class="progress-bar bg-primary" role="progressbar" style="width: 100%"></div>
                    </div>
                    <p class="mb-0 font-13">Data pengaduan diproses</p>
                </div>
            </div>
            <div class="col">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div>
                            <p class="mb-0">Selesai</p>
                            <h4 class="mb-0 text-success"><?php echo e($statistik['selesai']); ?></h4>
                        </div>
                        <div class="ms-auto"><i class="bx bx-check font-35 text-success"></i>
                        </div>
                    </div>
                    <div class="progress radius-10 my-2" style="height:4px;">
                        <div class="progress-bar bg-success" role="progressbar" style="width: 100%"></div>
                    </div>
                    <p class="mb-0 font-13">Data pengaduan diselesaikan</p>
                </div>
            </div>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon-php8\www\sampah-care\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>